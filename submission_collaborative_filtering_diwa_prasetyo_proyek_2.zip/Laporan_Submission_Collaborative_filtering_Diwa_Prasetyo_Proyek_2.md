
# Laporan Proyek Machine Learning - Diwa Prasetyo

## Domain 

Di era digital ini, persaingan antar bisnis semakin ketat. Pelanggan memiliki banyak pilihan produk dan layanan, sehingga penting bagi bisnis untuk memberikan pengalaman berbelanja yang personal dan menarik agar mereka dapat menonjol dari pesaing. Salah satu cara untuk mencapai hal ini adalah dengan menggunakan machine learning untuk merekomendasikan produk kepada pelanggan [1,2,3].

Machine learning dapat menganalisis data pelanggan, seperti riwayat pembelian, perilaku menjelajahi situs web, dan demografi, untuk mengidentifikasi pola dan preferensi [1,2]. Berdasarkan informasi ini, sistem rekomendasi yang didukung machine learning dapat memberikan rekomendasi produk yang dipersonalisasi kepada setiap pelanggan [1,2,3]. Hal ini dapat meningkatkan kepuasan pelanggan, mendorong penjualan, dan meningkatkan loyalitas pelanggan [1,2,3].

## Business Understanding

### Problem statement
Bagaimana cara untuk memberikan rekomendasi produk yang relevan?
### Goals
Mengetahui produk yang relevan dengan produk lainnya 
### Solution
Membuat sebuah machine learning dengan algoritma collaborative filtering untuk menemukan produk mana yang relevan dengan produk lainnya.
## Data Understanding
Dataset yang digunakan adalah dataset online retail yang dapat di unduh di [Laman Berikut.](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/bfc83e06b8c82c9d4f62fc5ffc433d3adc5ec05b/Online%20Retail.xlsx)

Dataset ini terdiri dari 541909 baris dan 8 kolom
* InvoiceNo : Nomor transaksi penjualan
* StockCode : Kode barang
* Description : Keterangan tentang barang yang dijual
* Quantity : Jumlah barang yang dibeli 
* InvoiceDate : Tanggal barang dibeli
* UnitPrice : Harga barang yang dijual
* CustomerID : ID pembeli barang 
* Country : Asal negara pembeli barang
### Visualisasi dan Insight
* Jumlah transaksi tiap negara
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/b9de392c2e969968e10d025dab81ae772646d51c/Screenshot%202024-07-01%20145838.png?raw=true)
Grafik batang yang menunjukkan jumlah transaksi untuk setiap negara. Ini memberikan wawasan tentang negara mana yang memiliki jumlah transaksi terbanyak.

* 10 Produk Terlaris
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/main/Screenshot%202024-07-01%20145900.png?raw=true)
Visualisasi ini memberikan wawasan tentang 10 produk mana yang paling populer di antara pelanggan. Ini bisa membantu dalam mengelola persediaan dan merencanakan strategi pemasaran untuk produk-produk yang paling laris.

* Hubungan antara Jumlah Item dan Harga Satuan
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/main/Screenshot%202024-07-01%20145907.png?raw=true)
Hubungan antara jumlah item yang dibeli dan harga satuan. Sumbu x dan y menggunakan skala logaritmik untuk menangani rentang nilai yang luas. Ini dapat membantu mengidentifikasi pola atau anomali dalam data pembelian.
Visualisasi ini memberikan wawasan tentang 10 produk mana yang paling populer di antara pelanggan. Ini bisa membantu dalam mengelola persediaan dan merencanakan strategi pemasaran untuk produk-produk yang paling laris.

* Jumlah Transaksi per Hari dalam 1 Pekan
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/main/Screenshot%202024-07-01%20145915.png?raw=true)
Visualisasi menggambarkan bahwa transaksi paling banyak dilakukan pada hari kamis, pada hari lainya relatif stabil namun pada hari sabtu tidak ada data transaksi.

* Heatmap Korelasi
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/main/Screenshot%202024-07-01%20090746.png?raw=true)
Heatmap ini menunjukkan korelasi antara fitur-fitur numerik dalam dataset. Angka-angka dalam setiap sel menunjukkan nilai korelasi Pearson antara dua fitur. Warna pada heatmap menunjukkan kekuatan dan arah hubungan; merah tua menunjukkan korelasi positif yang kuat, biru tua menunjukkan korelasi negatif yang kuat, dan warna yang lebih terang menunjukkan korelasi yang lemah.

* Tren Pendapatan tiap Bulan
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/main/Screenshot%202024-07-01%20150041.png?raw=true)
Membantu mengidentifikasi tren musiman dan fluktuasi pendapatan dari waktu ke waktu. Misalnya, apakah ada bulan-bulan tertentu dengan pendapatan yang lebih tinggi atau lebih rendah secara konsisten.

## Data Preparation

Mengecek missing value
* Missing Value adalah nilai yang hilang dari suatu baris, missing value perlu diatasi untuk mencegah data menjadi bias saat dilatih. Melakukan penghapusan baris yang tidak jadi membeli, dimana jumlah pembelian adalah 0

Data Duplikat
* Menghapus data duplikat

Melakukan penyesuaian kolom
* Menambah kolom baru yaitu TotalPrice yang merupakan hasil dari `Quantity * Unit Price`

Melakukan perubahan tipe data
* Melakukan perubahan tipe data `InvoiceDate` dari object ke datetime.

## Modeling
Membangun sebuah sistem rekomendasi produk dengan collaborative filtering. Collaborative filtering bergantung pada pendapat komunitas pengguna. Ia tidak memerlukan atribut untuk setiap itemnya seperti pada sistem berbasis konten. John S. Breese at al dalam makalahnya yang berjudul Empirical Analysis of Predictive Algorithms for Collaborative Filtering [4] menyatakan, memory based method umumnya memprediksi preferensi pengguna (pengguna aktif) dari database dan sampel atau data populasi pengguna lain. Ide di balik metode ini adalah untuk menentukan ukuran kesamaan antara pengguna atau item serta menemukan yang paling mirip.

* Langkah pertama dari proses pembuatan model adalah membuat sebuah matrix dengan binary transformation dimana jika terdapat sebuah transaksi akan bernilai lebih besar dari 0 dan jika terdapat transaksi akan lebih kecil dari 0.

* Menghitung matriks similaritas antar pengguna berdasarkan matrks Customer-Item yang telah dibuat sebelumnya. Dimana setiap baris dan kolom mewakilkan satu CustomerID dan nilai-nilai di dalamnya menunjukkan tingkat similaritas antara pasangan berdasarkan pola pembelian.

* Selanjutnya, menemukan pengguna-pengguna yang mirip dengan pengguna lainnyab berdasarkan matriks similaritas pengguna yang telah dihitung sebelumnya.

* Identifikasi item-item yang telah dibeli oleh dua pengguna tertentu 

* Merekomendasikan item-item yang dibeli oleh pengguna dengan CustomerID 12350.0 kepada pengguna dengan CustomerID 17935.0, berdasarkan perbedaan item-item yang dibeli antara keduanya.

* Kemudian, menghitung matriks similaritas antar item (item-item similarity) berdasarkan matriks Customer-Item.

* Lalu akan di dapat 10  item paling mirip dengan item yang memiliki StockCode 23166 berdasarkan matriks similaritas item-item `(item_similarity_matrix)`.
![image](https://github.com/DiwaPrasetyo02/submission-collaborative-filtering/blob/main/Screenshot%202024-07-02%20203727.png?raw=true)

Untuk menghitung matriks similaritas pengguna dibuat sebuah matriks `Customer-item` yang merepresentasikan jumlah pembelian setiap item oleh setiap pengguna. Selanjutnya, binarisasi matriks ini menjadi 1 (jika item dibeli) dan 0 (jika tidak). Lalu gunakan `cosine similarity` untuk menghitung tingkat kesamaan antar pengguna berdasarkan matriks `customer-item`.

Untuk menghitung matriks similaritas item. Gunakan `Transpose customer-item matrix` agar kolom mewakili pengguna dan baris mewakili item. Hal ini dilakukan untuk menghitung kesamaan item. Selanjutnya, hitung tingkat kesamaan antar item berdasarkan matriks Customer-Item yang di-transpose.
## Evaluasi
Hasil evaluasi menggunakan metrik precision dan recall menunjukkan beberapa temuan penting terkait performa sistem rekomendasi.

Precision (0.04)
* Penjelasan: Precision mengukur seberapa akurat sistem dalam merekomendasikan item yang relevan. Nilai precision 0.04 berarti hanya 4% dari item yang direkomendasikan benar-benar relevan atau dibeli oleh pengguna.
* Implikasi: Precision yang rendah menunjukkan bahwa sebagian besar item yang direkomendasikan tidak sesuai dengan preferensi pengguna. Hal ini mungkin disebabkan oleh data sparseness atau kurangnya informasi yang cukup untuk membuat prediksi yang lebih akurat.

Recall (0.71)
* Penjelasan: Recall mengukur seberapa banyak dari semua item yang relevan yang berhasil diidentifikasi oleh sistem rekomendasi. Nilai recall 0.71 menunjukkan bahwa sistem berhasil mengidentifikasi 71% dari item yang sebenarnya dibeli oleh pengguna.
* Implikasi: Recall yang tinggi menunjukkan bahwa sistem berhasil menangkap sebagian besar preferensi pengguna. Namun, ini juga menunjukkan bahwa ada ruang untuk meningkatkan rekomendasi agar lebih fokus pada item yang paling relevan.

Relevance Scores
Relevance Scores memberikan gambaran tentang kesamaan antar produk berdasarkan matriks similaritas item-item. Nilai relevansi antar produk yang didapat adalah sebagai berikut:

Relevance Scores: 
* 20615: 0.9999999999999997 
* 21832: 0.9999999999999998 
* 21864: 1.0000000000000004 
* 21866: 1.0 
* 20652: 1.0 
* 22412: 1.0000000000000004 
* 21908: 1.0000000000000002 
* 22551: 1.0000000000000004 
* 21915: 1.0 
* 22620: 1.0000000000000002 
* 22557: 1.0000000000000004 

Analisis Relevansi Antar Produk
Hasil evaluasi menunjukkan beberapa produk memiliki skor relevansi yang sangat tinggi (mendekati 1 atau bahkan lebih dari 1). Ini mengindikasikan bahwa produk-produk tersebut sangat mirip satu sama lain. Berikut adalah beberapa analisis lebih mendalam:

Produk dengan StockCode 21864, 21866, 20652, dan 22412 
* Kesamaan Tinggi: Produk ini memiliki nilai relevansi yang sangat tinggi (1 atau lebih). Ini menunjukkan bahwa mereka sangat mirip, mungkin karena kategori yang sama, fungsi yang mirip, atau sering dibeli bersama.
* Implikasi: Produk-produk ini bisa menjadi rekomendasi yang kuat untuk pengguna yang membeli salah satu dari mereka, karena kesamaan yang tinggi menunjukkan relevansi yang signifikan.

Mengapa ID A dan ID B Memiliki Relevansi yang Tinggi

* Untuk mendapatkan rekomendasi yang informatif, diperlukan analisis tentang alasan dua pengguna tertentu memiliki relevansi yang tinggi. Misalnya, dengan melihat pola pembelian mereka dan menemukan kesamaan.

Contoh: Pengguna dengan ID 12350.0 dan 17935.0
* Pola Pembelian: Jika kedua pengguna sering membeli item yang sama atau dari kategori yang sama, ini bisa menjelaskan relevansi yang tinggi.
* Atribut Pengguna: Faktor lain seperti demografi, waktu pembelian, atau jumlah pembelian juga bisa mempengaruhi kesamaan.

#### Kesimpulan
Hasil evaluasi menunjukkan bahwa sistem rekomendasi memiliki recall yang tinggi tetapi precision yang rendah. Untuk memahami relevansi antar produk dan memberikan rekomendasi yang lebih informatif, diperlukan analisis lebih lanjut kesamaan antar produk dan pola pembelian pengguna. Ini membantu mengidentifikasi area untuk perbaikan dalam sistem rekomendasi dan memberikan wawasan yang lebih dalam tentang preferensi pengguna.
## Referensi 

[1]Putra, M. A. (2019). Rekomendasi produk menggunakan machine learning: Sebuah tinjauan literatur. Jurnal Sistem Informasi, 13(2), 145-154.

[2]Laksana, A. (2014). Sistem rekomendasi menggunakan metode collaborative filtering berbasis machine learning. Jurnal Sistem Informasi, 8(1), 41-50. 

[3]Nusantara, R. A., & Xeratic, M. A. (2022). Implementasi machine learning pada aplikasi penjualan produk digital (studi kasus pada GrabKios). JIMFEB Universitas Brawijaya, 12(1), 69-85. 

[4] Breese, John S et al. "Empirical Analysis of Predictive Algorithms for Collaborative Filtering".